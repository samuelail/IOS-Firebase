//
//  HomeViewController.swift
//  FirebaseDemo
//
//  Created by Kingjulian on 1/9/18.
//  Copyright © 2018 Robert Canton. All rights reserved.
//

import UIKit
import Firebase


class HomeViewController: UIViewController {
    
    var ref: DatabaseReference!
    
    @IBOutlet weak var username: UILabel!
    @IBOutlet weak var curView: UIView!
    @IBOutlet weak var balanceLbl: UILabel!
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ref = Database.database().reference()
        
        let bal = "10"
        let userID = Auth.auth().currentUser?.uid
        
        
        // Custom View Design
        self.curView.layer.cornerRadius = 7
        self.curView.clipsToBounds = true
        
        
        // Read post from the database
        
        ref.child("users").child(userID!).observeSingleEvent(of: .value, with: { (snapshot) in
            // Get username
            let value = snapshot.value as? NSDictionary
            let username = value?["username"] as? String ?? ""
            let balance = value?["balance"] as? String ?? ""
            print(username)
            print(balance)
            
            self.username.text = username
            if balance == "" {
                self.balanceLbl.text = "00.00"
            }
            else{
                self.balanceLbl.text = balance
            }
            
            // ...
        }) { (error) in
            print(error.localizedDescription)
        }
    }
    
   

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func logoutBtn(_ sender: Any) {
        try! Auth.auth().signOut()
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func logout(_ sender: UIBarButtonItem) {
        
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
