# Firebase Demo

Starter project for my Swift + Firebase - Part 1: Setup & Authentication tutorial [video](https://www.youtube.com/watch?v=UPKCULKi0-A).
